﻿using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicatonProcess.December2020.Domain.Models
{
    public class ApplicantExample: IExamplesProvider<Applicant>
    {
        public object GetExamples()
        {
            return new Applicant
            {
                Name = "Deepu",
                FamilyName = "Panicker",
                Address = "Bengaluru City",
                CountryOfOrigin = "India",
                EmailAddress = "test@gmail.com",
                Age = 20,
                Hired = true
            };
        }

        Applicant IExamplesProvider<Applicant>.GetExamples()
        {
            return new Applicant
            {
                Name = "Deepu",
                FamilyName = "Panicker",
                Address = "Bengaluru City",
                CountryOfOrigin = "India",
                EmailAddress = "test@gmail.com",
                Age = 20,
                Hired = true
            };
        }
    }
}
