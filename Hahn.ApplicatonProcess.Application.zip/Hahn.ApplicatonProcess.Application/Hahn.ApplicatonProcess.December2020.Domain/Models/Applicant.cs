﻿using FluentValidation;
using System.Net;
using System.Net.Http;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using System.ComponentModel;

namespace Hahn.ApplicatonProcess.December2020.Domain.Models
{
    public class Applicant
    {
        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity), Key]
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string FamilyName { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string CountryOfOrigin { get; set; }
        [Required]
        public string EmailAddress { get; set; }
        [Required]
        public int Age { get; set; }
        [DefaultValue(false)]
        public bool Hired { get; set; }
    }

    public class ApplicantValidator : AbstractValidator<Applicant>
    {
        public ApplicantValidator()
        {
            RuleFor(x => x.Id).NotNull();
            RuleFor(x => x.Name).MinimumLength(5);
            RuleFor(x => x.FamilyName).MinimumLength(5);
            RuleFor(x => x.Address).MinimumLength(10);
            RuleFor(x => x.Age).InclusiveBetween(18, 60);
            RuleFor(x => x.CountryOfOrigin).Must(x => IsCountryValid(x)).WithMessage("Country is invalid");
            RuleFor(x => x.EmailAddress).EmailAddress(FluentValidation.Validators.EmailValidationMode.AspNetCoreCompatible).WithMessage("Email address is invalid");
        }

        public bool IsCountryValid(string countryName)
        {
            using var client = new HttpClient();
            var result = client.GetAsync($"https://restcountries.eu/rest/v2/name/{countryName}?fullText=true").Result;
            if (result.StatusCode == HttpStatusCode.OK)
            {
                return true;
            }

            return false;
        }
    }
}