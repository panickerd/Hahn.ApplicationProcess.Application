import * as environment from '../config/environment.json';
import { PLATFORM } from 'aurelia-pal';
import { TCustomAttribute } from 'aurelia-i18n';
import Backend from 'i18next-xhr-backend';
export function configure(aurelia) {
    aurelia.use
        .standardConfiguration()
        .developmentLogging()
        .plugin(PLATFORM.moduleName('aurelia-validatejs'))
        .plugin(PLATFORM.moduleName('aurelia-validation'))
        .plugin(PLATFORM.moduleName('aurelia-dialog'), function (config) {
        config.useDefaults();
        config.settings.lock = true;
        config.settings.centerHorizontalOnly = false;
        config.settings.startingZIndex = 5;
    });
    aurelia.use.developmentLogging(environment.debug ? 'debug' : 'warn');
    if (environment.testing) {
        aurelia.use.plugin(PLATFORM.moduleName('aurelia-testing'));
    }
    aurelia.use.plugin(PLATFORM.moduleName('aurelia-i18n'), function (instance) {
        var aliases = ['t', 'i18n'];
        TCustomAttribute.configureAliases(aliases);
        instance.i18next.use(Backend);
        return instance.setup({
            fallbackLng: 'de',
            whitelist: ['en', 'de'],
            preload: ['en', 'de'],
            ns: 'global',
            defaultNS: 'global',
            fallbackNS: false,
            attributes: aliases,
            lng: 'en',
            debug: true,
            backend: {
                loadPath: 'locales/{{lng}}/{{ns}}.json',
            }
        });
    });
    aurelia.start().then(function () { return aurelia.setRoot(PLATFORM.moduleName('app')); });
}
//# sourceMappingURL=main.js.map