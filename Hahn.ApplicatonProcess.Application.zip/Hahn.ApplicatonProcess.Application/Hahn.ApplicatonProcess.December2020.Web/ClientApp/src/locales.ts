import {I18N} from 'aurelia-i18n';
import {inject} from 'aurelia-dependency-injection';

@inject(I18N)

export class Locales {
    i18n = null;
    locales = [];
    currentLocale = null;
    constructor(i18n) {
      this.i18n = i18n;
      this.locales = [
        {
          title: "English",
          code: "en"
        },
        {
          title: "German",
          code: "de"
        }
      ]
      this.currentLocale = this.i18n.getLocale();
    }

    setLocale(locale) {
        let code = locale.code
        if(this.currentLocale !== code) {
          this.i18n.setLocale(code);
          this.currentLocale = code;
        }
      }
  }