import {inject} from 'aurelia-dependency-injection';
import {HttpClient} from 'aurelia-fetch-client';
import {DialogService} from 'aurelia-dialog';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import {
  ValidationControllerFactory,
  ValidationController,
  ValidationRules
} from 'aurelia-validation';
import {BootstrapFormRenderer} from './bootstrap-form-renderer';
import {Prompt} from './components/modal';
import {PLATFORM} from 'aurelia-pal';

let httpClient = new HttpClient();

@inject(ValidationControllerFactory, DialogService, Router, I18N)
export class App {
  name = null;
  familyName = null;
  address = null;
  countryOfOrigin = null;
  emailAddress = null;
  age = null;
  hired = '';
  controller = null;
  dialogService = null;
  router = null;
  countries = [];
  validForm = '';
  i18N = null;
  constructor(controllerFactory, dialogService, router, i18N) {
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.dialogService = dialogService;
    this.router = router;
    this.i18N = i18N;
  }
  activate(params) {
    httpClient.get('https://restcountries.eu/rest/v2/all')
    .then(response => response.json())
      .then(result => 
        result.forEach(element => {
          this.countries.push(element.name);
      })
    )
  };

  configureRouter(config, router) {
    config.map([
      {
        route: ['', '*path']
        , name: 'confirm'
        , moduleId: PLATFORM.moduleName('./components/confirm/confirm')
        , nav: true
      }
    ]);

    this.router = router;
  }
  
  submit() {
    
    this.controller.validate();
    httpClient.fetch('https://localhost:44395/Applicant', {
     method: 'POST',
     body: JSON.stringify({
      Name: this.name,
      FamilyName: this.familyName,
      Address: this.address,
      CountryOfOrigin: this.countryOfOrigin,
      EmailAddress: this.emailAddress,
      Age: this.age,
      Hired: this.hired == '' ? false : this.hired
     }),
     headers: {
       "content-type": "application/json; charset=utf-8",
       "authorization": "Basic dXNlcjE6cGFzc3dvcmQx"
      }
    })
    .then(response => {
      //this.router.navigate("confirm");
      this.dialogService.open({ viewModel: Prompt, model: this.i18N.tr('applicantSaved') });
      this.resetFormElements();
    })
    .catch(error => {
      this.dialogService.open({viewModel: Prompt, model: error});
    });
  }

  resetForm(): void {
    this.dialogService.open({ viewModel: Prompt, model: this.i18N.tr('areYouSure') })
    .whenClosed().then(response => {   
      if (!response.wasCancelled) {
         this.resetFormElements();
      } else {
         console.log('cancelled');
      }
   });
  }

  resetFormElements() {
    this.name = null;
    this.familyName = null;
    this.address = null;
    this.emailAddress = null;
    this.age = null;
    this.hired = '';
  }

  get disableSendButton() {
    this.controller.validate().then(v => {
      this.validForm = v.valid;
    });
    return Boolean(this.validForm) === true ? false : true;
  }

  get disableResetButton() {
    if (this.name || this.familyName || this.address || this.emailAddress
    || this.age || String(this.hired).length > 0){
      return false;
    }
    return true;
  }
}

ValidationRules
  .ensure((o: App) => o.name).displayName("Name").required().minLength(5)
  .ensure((o: App) => o.familyName).displayName("Family Name").required().minLength(5)
  .ensure((o: App) => o.address).displayName("Address").required().minLength(10)
  .ensure((o: App) => o.age).displayName("Age").required().between(19, 61)
  .ensure((o: App) => o.emailAddress).displayName("Email Address").required().email()
  .on(App);
