export function configure(config) {
}
//# sourceMappingURL=index.js.map