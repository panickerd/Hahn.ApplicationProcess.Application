var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { inject } from 'aurelia-dependency-injection';
import { HttpClient } from 'aurelia-fetch-client';
import { DialogService } from 'aurelia-dialog';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { ValidationControllerFactory, ValidationRules } from 'aurelia-validation';
import { BootstrapFormRenderer } from './bootstrap-form-renderer';
import { Prompt } from './components/modal';
import { PLATFORM } from 'aurelia-pal';
var httpClient = new HttpClient();
var App = (function () {
    function App(controllerFactory, dialogService, router, i18N) {
        this.name = null;
        this.familyName = null;
        this.address = null;
        this.countryOfOrigin = null;
        this.emailAddress = null;
        this.age = null;
        this.hired = '';
        this.controller = null;
        this.dialogService = null;
        this.router = null;
        this.countries = [];
        this.validForm = '';
        this.i18N = null;
        this.controller = controllerFactory.createForCurrentScope();
        this.controller.addRenderer(new BootstrapFormRenderer());
        this.dialogService = dialogService;
        this.router = router;
        this.i18N = i18N;
    }
    App.prototype.activate = function (params) {
        var _this = this;
        httpClient.get('https://restcountries.eu/rest/v2/all')
            .then(function (response) { return response.json(); })
            .then(function (result) {
            return result.forEach(function (element) {
                _this.countries.push(element.name);
            });
        });
    };
    ;
    App.prototype.configureRouter = function (config, router) {
        config.map([
            {
                route: ['', '*path'],
                name: 'confirm',
                moduleId: PLATFORM.moduleName('./components/confirm/confirm'),
                nav: true
            }
        ]);
        this.router = router;
    };
    App.prototype.submit = function () {
        var _this = this;
        this.controller.validate();
        httpClient.fetch('https://localhost:44395/Applicant', {
            method: 'POST',
            body: JSON.stringify({
                Name: this.name,
                FamilyName: this.familyName,
                Address: this.address,
                CountryOfOrigin: this.countryOfOrigin,
                EmailAddress: this.emailAddress,
                Age: this.age,
                Hired: this.hired == '' ? false : this.hired
            }),
            headers: {
                "content-type": "application/json; charset=utf-8",
                "authorization": "Basic dXNlcjE6cGFzc3dvcmQx"
            }
        })
            .then(function (response) {
            _this.dialogService.open({ viewModel: Prompt, model: _this.i18N.tr('applicantSaved') });
            _this.resetFormElements();
        })
            .catch(function (error) {
            _this.dialogService.open({ viewModel: Prompt, model: error });
        });
    };
    App.prototype.resetForm = function () {
        var _this = this;
        this.dialogService.open({ viewModel: Prompt, model: this.i18N.tr('areYouSure') })
            .whenClosed().then(function (response) {
            if (!response.wasCancelled) {
                _this.resetFormElements();
            }
            else {
                console.log('cancelled');
            }
        });
    };
    App.prototype.resetFormElements = function () {
        this.name = null;
        this.familyName = null;
        this.address = null;
        this.emailAddress = null;
        this.age = null;
        this.hired = '';
    };
    Object.defineProperty(App.prototype, "disableSendButton", {
        get: function () {
            var _this = this;
            this.controller.validate().then(function (v) {
                _this.validForm = v.valid;
            });
            return Boolean(this.validForm) === true ? false : true;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(App.prototype, "disableResetButton", {
        get: function () {
            if (this.name || this.familyName || this.address || this.emailAddress
                || this.age || String(this.hired).length > 0) {
                return false;
            }
            return true;
        },
        enumerable: false,
        configurable: true
    });
    App = __decorate([
        inject(ValidationControllerFactory, DialogService, Router, I18N),
        __metadata("design:paramtypes", [Object, Object, Object, Object])
    ], App);
    return App;
}());
export { App };
ValidationRules
    .ensure(function (o) { return o.name; }).displayName("Name").required().minLength(5)
    .ensure(function (o) { return o.familyName; }).displayName("Family Name").required().minLength(5)
    .ensure(function (o) { return o.address; }).displayName("Address").required().minLength(10)
    .ensure(function (o) { return o.age; }).displayName("Age").required().between(19, 61)
    .ensure(function (o) { return o.emailAddress; }).displayName("Email Address").required().email()
    .on(App);
//# sourceMappingURL=app.js.map