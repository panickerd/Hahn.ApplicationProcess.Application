var Confirm = (function () {
    function Confirm() {
    }
    return Confirm;
}());
export { Confirm };
//# sourceMappingURL=confirm.js.map