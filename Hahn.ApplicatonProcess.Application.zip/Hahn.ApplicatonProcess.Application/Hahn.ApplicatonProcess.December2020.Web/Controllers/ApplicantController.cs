﻿using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;
using System;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    [SwaggerResponse(401, "Unauthorized")]
    public class ApplicantController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

        public ApplicantController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet("{id}")]
        [SwaggerResponse(200, Type = typeof(Applicant))]
        [SwaggerResponse(404, "Applicant not found")]
        public IActionResult Get(int id)
        {
            var applicant = _unitOfWork.Applicants.GetByID(id);
            return applicant == null ? NotFound() : Ok(applicant);
        }

        [HttpPost]
        [SwaggerRequestExample(typeof(Applicant), typeof(ApplicantExample))]
        [SwaggerResponse(201, "Applicant saved", typeof(Applicant))]
        [SwaggerResponse(400, "Bad Request", typeof(ValidationProblemDetails))]
        public IActionResult Post([FromBody] Applicant applicant)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _unitOfWork.Applicants.Insert(applicant);
            _unitOfWork.Commit();
            return Created(new Uri($"/Applicant/{applicant.Id}", UriKind.Relative), applicant);
        }

        [HttpPut("{id}")]
        [SwaggerRequestExample(typeof(Applicant), typeof(ApplicantExample))]
        [SwaggerResponse(200, "Applicant details changed")]
        [SwaggerResponse(400, "Bad Request", typeof(ValidationProblemDetails))]
        public IActionResult Put(int id, [FromBody] Applicant applicant)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            applicant.Id = id;
            _unitOfWork.Applicants.Update(applicant);
            _unitOfWork.Commit();
            return Ok(applicant);
        }

        [HttpDelete("{id}")]
        [SwaggerResponse(204, "Applicant deleted")]
        [SwaggerResponse(400, "Bad Request")]
        public IActionResult Delete(int id)
        {
            if (_unitOfWork.Applicants.GetByID(id) == null)
            {
                return BadRequest("Invalid applicant id");
            }
            _unitOfWork.Applicants.Delete(id);
            _unitOfWork.Commit();
            return NoContent();
        }
    }
}