﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        private BaseRepository<Applicant> _applicants;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }

        public void Commit()
        {
            _context.SaveChanges();
        }

        public IRepository<Applicant> Applicants
        {
            get
            {
                return _applicants ??
                (_applicants = new BaseRepository<Applicant>(_context));
            }
        }
    }
}
