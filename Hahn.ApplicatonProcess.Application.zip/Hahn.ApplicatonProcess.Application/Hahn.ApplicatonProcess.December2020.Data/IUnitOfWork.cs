﻿using Hahn.ApplicatonProcess.December2020.Domain.Models;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public interface IUnitOfWork
    {
        IRepository<Applicant> Applicants { get; }
        void Commit();
    }
}
