﻿using System;
using System.Collections.Generic;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public interface IRepository<T> : IDisposable
    {
        IEnumerable<T> GetAll();

        T GetByID(object id);

        void Update(T entity);

        void Insert(T entity);

        void Delete(object id);
    }
}
